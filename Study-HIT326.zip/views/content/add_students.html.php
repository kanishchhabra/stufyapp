<?php
require $_SERVER['DOCUMENT_ROOT'] . "/views/partials/header.html.php";

?>

<h1>Add Students</h1>

<?php
include PARTIALS_PATH . "/add_students._form.html.php.";
?>