</body>
<footer class="card-footer mt-3 bg-primary">
    <div class="card-body">
        <span class="text-light">
            <strong>&#169 Kanish Chhabra 2021. All rights Reserved</strong><br>
            With assistance of Shaakya Weerasundra.
        </span>
    </div>
    <script src=<?php echo HTML_PARTIALS_PATH . "js/bootstrap.bundle.js" ?>></script>
    <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
    <script src=<?php echo HTML_PARTIALS_PATH . "js/interactions.js" ?>></script>

    </html>