<div id=<?php echo $button_email ?>>
    <button id=<?php echo $button_email ?> class="actionRequest btn <?php echo $button_class ?>" name=<?php echo $button_name ?>>
        <?php echo $button_value; ?>
    </button>
    <span>&nbsp;</span>
</div>