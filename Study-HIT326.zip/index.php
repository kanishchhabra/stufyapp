<?php
require $_SERVER['DOCUMENT_ROOT'] . "/controller/paths.php";
require CONTROLLER_PATH . "/main.php";
